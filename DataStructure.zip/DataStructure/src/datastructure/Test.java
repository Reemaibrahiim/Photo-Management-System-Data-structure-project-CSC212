
package datastructure;
public class Test {
    //this main class is specific for BST
    public static void main(String[] args) {
    
        InvIndexPhotoManager manager = new InvIndexPhotoManager();
        
        Photo photo1 = new Photo("hedgehog.jpg",toTagsLinkedList("animal, hedgehog, apple, grass, green"));
        manager.addPhoto(photo1);
        
        Photo photo2 = new Photo("bear.jpg",toTagsLinkedList("animal, bear, cab, grass, wind"));
        manager.addPhoto(photo2);
        
        Photo photo3 = new Photo("orange-butterfly.jpg",toTagsLinkedList("insect, butterfly, flower, color"));
        manager.addPhoto(photo3);
        
     
        Photo photo4 = new Photo("panda.jpg",toTagsLinkedList("animal, bear, panda, grass"));
                manager.addPhoto(photo4);
                
        Photo photo5 = new Photo("wolf.jpg",toTagsLinkedList("animal, wolf, mountain, sky , snow , cloud"));
                manager.addPhoto(photo5);
        
                Photo photo6 = new Photo("fox.jpg",toTagsLinkedList("animal, fox, tree, forest , grass"));
                                manager.addPhoto(photo6);

                                
        InvAlbum album1 = new InvAlbum("Album1", "bear", manager);
        InvAlbum album2 = new InvAlbum("Album2", "animal AND grass", manager);
        InvAlbum album3 = new InvAlbum("Album3", "", manager);
        
        
        System.out.println("Get photo1 path and tags:");
        System.out.println("photo1 path: " + photo1.getPath());
        
        //You can get the list of tags of photo1 by calling photo1.getTags().
        LinkedList<String> tags = photo1.getTags();
        
        //You can write a method that prints the list of tags of photo1.
        System.out.println(photo1.getPath());
        printLL(tags);
        
        System.out.println("\n\nGet album1 name, condition, and photos:");
        System.out.println("album1 name: " + album1.getName());
        System.out.println("album1 condition: " + album1.getCondition());
         //You can get the list of photos in album2 by calling album2.getPhotos().
        LinkedList<Photo> photos = album1.getPhotos();
        //You can write a method that prints the list of photos in album2.
        System.out.println(album1.getCondition());
        printLLPhoto(photos);
             
        System.out.println("\n\nGet album2 name, condition, and photos:");
        System.out.println("album2 name: " + album2.getName());
        System.out.println("album2 condition: " + album2.getCondition());
  //You can get the list of photos in album2 by calling album2.getPhotos().
        photos = album2.getPhotos();
        //You can write a method that prints the list of photos in album2.
        System.out.println(album2.getCondition());
        printLLPhoto(photos);
      
        System.out.println("\n\nGet album3 name, condition, and photos:");
        System.out.println("album3 name: " + album3.getName());
        System.out.println("album3 condition: " + album3.getCondition());
  //You can get the list of photos in album2 by calling album2.getPhotos().
        photos = album3.getPhotos();
        //You can write a method that prints the list of photos in album2.
        System.out.println(album3.getCondition());
        printLLPhoto(photos);
        
        System.out.println("Delete the photo ’bear.jpg’:");
        manager.deletePhoto("bear.jpg");
    }
    
    private static LinkedList<String> toTagsLinkedList(String tags) {
        LinkedList<String> result = new LinkedList<String>();
        String[] tagsArray = tags.split("\\s*,\\s*");
        for (int i = 0; i < tagsArray.length; i++) {
            result.insert(tagsArray[i]);
        }
        return result;
    }
    
        private static void printLL(LinkedList<String> list){
            list.findFirst();
            if(list.empty()) 
                return;
            while(true)
            {
                System.out.print(list.retrieve() + " ");
                if(list.last()) 
                    return;
                list.findNext();
            }
        }

        private static void printLLPhoto(LinkedList<Photo> list){
            list.findFirst();
            if(list.empty()) 
                return;
            while(true)
            {
                System.out.println(list.retrieve().getPath());
                if(list.last()) 
                    return;
                list.findNext();
            }
        }
    
}