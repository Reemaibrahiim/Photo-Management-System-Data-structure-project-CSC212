
package datastructure;

public class Test2 {
//this main class is specific for linkedList
    public static void main(String[] args) {

       PhotoManager manager = new PhotoManager();

        Photo photo1 = new Photo("hedgehog.jpg", toTagsLinkedList("animal", "hedgehog", "apple", "grass", "green"));
        manager.addPhoto(photo1);

        Photo photo2 = new Photo("bear.jpg", toTagsLinkedList("animal", "bear", "cab", "grass", "wind"));
        manager.addPhoto(photo2);

        Photo photo3 = new Photo("orange-butterfly.jpg", toTagsLinkedList("insect", "butterfly", "flower", "color"));
        manager.addPhoto(photo3);

        Photo photo4 = new Photo("panda.jpg", toTagsLinkedList("animal", "bear", "panda", "grass"));
        manager.addPhoto(photo4);

        Photo photo5 = new Photo("wolf.jpg", toTagsLinkedList("animal", "wolf", "mountain", "sky", "snow", "cloud"));
        manager.addPhoto(photo5);

        Photo photo6 = new Photo("fox.jpg", toTagsLinkedList("animal", "fox", "tree", "forest"));
        manager.addPhoto(photo6);

        Album album1 = new Album("Album1", "bear", manager);
        Album album2 = new Album("Album2", "animal AND grass", manager);
        Album album3 = new Album("Album3", "insect", manager);

        System.out.println("Get photo6 path and tags:");
        System.out.println("photo6 path: " + photo6.getPath());
        System.out.println(photo6);

        System.out.println("\nGet album3 name, condition, and photos:");
        System.out.println("album3 name: " + album3.getName());
        System.out.println("album3 condition: " + album3.getCondition());

        LinkedList<Photo> photos = album3.getPhotos();
        photos.findFirst();
        for (int i = 0; i < photos.getSize(); i++) {
            Photo p = photos.retrieve();
            System.out.println(p.getPath());
            photos.findNext();
        }
    }

    public static LinkedList<String> toTagsLinkedList(String... tags) {
        LinkedList<String> list = new LinkedList<>();
        for (String tag : tags) {
            list.insert(tag);
        }
        return list;
    }
}
